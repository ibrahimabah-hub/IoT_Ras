import Crypt2 as cs
"""from flask import Flask, render_template, url_for, request, redirect

app = Flask(__name__)"""

priv_key=cs.private_key_rsa

def activate(encrypted, cypher):
    decrypted=cs.decrypt(encrypted, cypher)
    return decrypted

"""@app.route('/', methods=['GET','POST'])
def index():
    return render_template('closed.html')
if __name__ == "__main__":  
    app.run(debug=True)"""