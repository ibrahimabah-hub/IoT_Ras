from flask import Flask, render_template, url_for, request, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import Crypt2 as cs
import rasapp 

app = Flask(__name__)

key_byte=b"TempPassw0rd"

cipher, sym_key=cs.generate_key(key_byte)
encrypted=cs.pub_encrypt(sym_key)

@app.route('/', methods=['GET','POST'])
def index():
   if request.method=='POST':
       return redirect('/ask')
   else:
      return render_template('index.html')

@app.route('/ask')
def ask():
    if rasapp.activate(encrypted, cipher).decode() == key_byte.decode():
        return redirect('/activated')
    else:
        return('Encryption Failed')

@app.route('/activated')
def active():
    return render_template('closed.html')

if __name__ == "__main__":  
    app.run(debug=True)