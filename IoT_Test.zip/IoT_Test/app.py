from flask import Flask, render_template, url_for, request, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import random,string
import Cryptosystem as cs
import rasapp 

app = Flask(__name__)

def generate_random_string(length):
    characters = string.ascii_letters + string.digits  # Includes both letters and digits
    random_string = ''.join(random.choice(characters) for i in range(length))
    return random_string

# Generate a random string of length 2048
plain_key = generate_random_string(2048)

sym_key=cs.generate_key(plain_key)

@app.route('/', methods=['GET','POST'])
def index():
   if request.method=='POST':
       encrypted=cs.pub_encrypt(sym_key)
       return redirect('/ask/'.join(encrypted))
   else:
      return render_template('index.html')

@app.route('/ask/<key>')
def ask(key):
    if rasapp.activate(key) == plain_key:
        return redirect('/activated')
    else:
        return('Encryption Failed')

@app.route('/activated')
def active():
    return render_template('closed.html')

if __name__ == "__main__":  
    app.run(debug=True)