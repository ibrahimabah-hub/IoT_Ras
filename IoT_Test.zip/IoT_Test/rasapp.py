from flask import Flask, render_template, url_for, request, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import random,string

app = Flask(__name__)

def generate_random_string(length):
    characters = string.ascii_letters + string.digits  # Includes both letters and digits
    random_string = ''.join(random.choice(characters) for i in range(length))
    return random_string

# Generate a random string of length 2048
plain_key = generate_random_string(2048)


@app.route('/', methods=['GET','POST'])
def index():
   if request.method=='POST':
       return redirect('/')
   else:
      return render_template('index.html')

if __name__ == "__main__":  
    app.run(debug=True)